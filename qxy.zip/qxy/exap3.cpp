#include<iostream>
#include<vector>
#include<string>

using namespace std;

int main()
{
	cout << "Please enter a number in the range 1-3999: ";

	int x;
	cin >> x;

	vector<string> r_nums = {"M", "CM", "D","CD", "C", "XC", "L","XL", "X","IX", "V", "IV","I"};
	vector<int> num = {1000,900, 500,400, 100,90, 50, 40, 10, 9, 5, 4, 1};

	string res = "";

	for(int i = 0; i != r_nums.size(); i++)
	{
		while(x >= num[i])
		{
			res += r_nums[i];
			x -= num[i];
		}
	}

	cout << res <<endl;
	
	return 0;
}
