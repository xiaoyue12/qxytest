#include<iostream>
#include<vector>

using namespace std;

vector<int> sort(int len, vector<int>& exp)
{
	int half_len = len/2;

	for(int i = 0; i != half_len; i++)
	{
		int temp = exp[half_len+i];
		exp.erase(exp.begin()+half_len+i);
		exp.insert(exp.begin()+i*2+1, temp);
	}
	return exp;
}

int main()
{
	cout << "Please enter several numbers：";

	int x;
	vector<int> exp;
	while(cin >> x)
		exp.push_back(x);
	
	typedef vector<int>::size_type vec_sz;
	vec_sz size = exp.size();

	vector<int> res = sort(size, exp);

	for(int i = 0; i != size; i++)
		cout<< res[i] << " ";
	
	cout << endl;
	
	return 0;
}
